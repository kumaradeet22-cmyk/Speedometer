# MaxSpeedo – animated GPS speedometer for Android

Bicycle / Motorcycle / Car modes, animated needle gauge, trip stats, speed-limit alert, HUD mode.

## Get the APK (cloud build, no Android Studio needed)

1. Create a free account at github.com and make a **new repository** (any name, public or private).
2. Upload **all files of this folder** (keep the folder structure, including the hidden `.github` folder).
   Easiest on a computer: unzip, then drag the contents into the repo page ("Add file → Upload files").
3. Open the **Actions** tab → **Build APK** → **Run workflow** (it also runs automatically on every push).
4. After ~3–5 minutes open the finished run → **Artifacts** → download **MaxSpeedo-debug-apk**.
5. Unzip it, copy `app-debug.apk` to your phone, tap it, allow "Install unknown apps", install.

## Or build locally
Open this folder in Android Studio and press Run, or run `gradle assembleDebug`
(APK appears in `app/build/outputs/apk/debug/`).

## Features
- Animated analog gauge with glowing arc, sweep-on-start, pulsing red limit warning
- Vehicle modes: Bicycle (0–60), Motorcycle (0–240), Car (0–320 km/h) with matching scales and colors
- Units: km/h, mph, knots (distance km / mi / nmi)
- Trip: distance, max speed (marker on gauge), average speed, moving time – saved between launches
- Speed limit alert: beep + vibration + red pulse (tap Limit to cycle values)
- Altitude, compass heading, GPS signal quality
- HUD mode (mirrored for windshield reflection; tap gauge to exit)
- Demo mode to preview animation without moving
- Landscape layout, screen stays on

Notes: speed comes from GPS, so it works outdoors; tracking pauses if you leave the app.
