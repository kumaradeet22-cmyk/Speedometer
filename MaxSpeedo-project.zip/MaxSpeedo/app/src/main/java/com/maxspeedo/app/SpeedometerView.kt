package com.maxspeedo.app

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.BlurMaskFilter
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.SweepGradient
import android.graphics.Typeface
import android.util.AttributeSet
import android.view.View
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.DecelerateInterpolator
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

/** Animated analog + digital speedometer drawn entirely with Canvas (no dependencies). */
class SpeedometerView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    var maxScale = 200f
        set(value) { field = value; invalidate() }
    var majorStep = 20f
        set(value) { field = value; invalidate() }
    var unitLabel = "km/h"
        set(value) { field = value; invalidate() }
    var caption = ""
        set(value) { field = value; invalidate() }
    var limit = 0f
        set(value) { field = value; invalidate() }
    var recordedMax = 0f
        set(value) { field = value; invalidate() }
    var accent: Int = Color.parseColor("#00E5FF")
        set(value) {
            field = value
            needle.color = value
            needle.setShadowLayer(10f * d, 0f, 0f, value)
            invalidate()
        }

    /** Currently displayed (animated) speed in the active unit. */
    var shown = 0f
        private set

    private val d = resources.displayMetrics.density
    private val rect = RectF()
    private val needlePath = Path()
    private var anim: ValueAnimator? = null

    private fun paint(style: Paint.Style) = Paint(Paint.ANTI_ALIAS_FLAG).apply { this.style = style }

    private val track = paint(Paint.Style.STROKE).apply {
        color = Color.parseColor("#1B2530"); strokeCap = Paint.Cap.ROUND
    }
    private val prog = paint(Paint.Style.STROKE).apply { strokeCap = Paint.Cap.ROUND }
    private val glow = paint(Paint.Style.STROKE).apply {
        strokeCap = Paint.Cap.ROUND
        alpha = 150
        maskFilter = BlurMaskFilter(12f * d, BlurMaskFilter.Blur.NORMAL)
    }
    private val minorTick = paint(Paint.Style.STROKE).apply {
        color = Color.parseColor("#5C6B7A"); strokeWidth = 1.5f * d
    }
    private val majorTick = paint(Paint.Style.STROKE).apply {
        color = Color.WHITE; strokeWidth = 2.5f * d
    }
    private val labelPaint = paint(Paint.Style.FILL).apply {
        color = Color.parseColor("#C9D3DC"); textAlign = Paint.Align.CENTER
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
    }
    private val speedPaint = paint(Paint.Style.FILL).apply {
        color = Color.WHITE; textAlign = Paint.Align.CENTER
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
    }
    private val unitPaint = paint(Paint.Style.FILL).apply {
        color = Color.parseColor("#8FA1B3"); textAlign = Paint.Align.CENTER
    }
    private val captionPaint = paint(Paint.Style.FILL).apply {
        color = Color.parseColor("#5C6B7A"); textAlign = Paint.Align.CENTER
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
    }
    private val needle = paint(Paint.Style.FILL).apply { color = accent }
    private val hub = paint(Paint.Style.FILL).apply { color = Color.parseColor("#0B0F14") }
    private val hubRing = paint(Paint.Style.STROKE).apply { strokeWidth = 3f * d }
    private val dot = paint(Paint.Style.FILL)
    private val warn = paint(Paint.Style.STROKE).apply {
        color = Color.parseColor("#FF1744"); strokeWidth = 4f * d
    }

    init {
        // Needed for blur / shadow glow on all API levels.
        setLayerType(LAYER_TYPE_SOFTWARE, null)
        needle.setShadowLayer(10f * d, 0f, 0f, accent)
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        val cx = w / 2f
        val cy = h / 2f
        val colors = intArrayOf(
            Color.parseColor("#00E5FF"),
            Color.parseColor("#00E676"),
            Color.parseColor("#FFEA00"),
            Color.parseColor("#FF1744"),
            Color.parseColor("#FF1744")
        )
        val pos = floatArrayOf(0f, 0.25f, 0.5f, 0.75f, 1f)
        val sg = SweepGradient(cx, cy, colors, pos)
        val m = Matrix()
        m.postRotate(135f, cx, cy)
        sg.setLocalMatrix(m)
        prog.shader = sg
        glow.shader = sg
    }

    /** Smoothly animate the needle to [target] (in the currently selected unit). */
    fun setSpeed(target: Float, durationMs: Long = 400L) {
        anim?.cancel()
        anim = ValueAnimator.ofFloat(shown, target).apply {
            duration = durationMs
            interpolator = DecelerateInterpolator()
            addUpdateListener {
                shown = it.animatedValue as Float
                invalidate()
            }
            start()
        }
    }

    /** Classic start-up sweep: 0 -> max -> 0. */
    fun startupSweep() {
        anim?.cancel()
        anim = ValueAnimator.ofFloat(shown, maxScale, 0f).apply {
            duration = 1700L
            interpolator = AccelerateDecelerateInterpolator()
            addUpdateListener {
                shown = it.animatedValue as Float
                invalidate()
            }
            start()
        }
    }

    private fun Canvas.centerText(s: String, x: Float, y: Float, p: Paint) {
        val fm = p.fontMetrics
        drawText(s, x, y - (fm.ascent + fm.descent) / 2f, p)
    }

    private fun angleFor(value: Float): Double =
        Math.toRadians(135.0 + 270.0 * (value / maxScale).coerceIn(0f, 1f))

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val cx = w / 2f
        val cy = h / 2f
        val r = min(w, h) / 2f - 14f * d
        if (r <= 0f) return

        val frac = (shown / maxScale).coerceIn(0f, 1f)
        val ringW = r * 0.085f
        val arcR = r - ringW / 2f
        rect.set(cx - arcR, cy - arcR, cx + arcR, cy + arcR)

        // Track + glowing progress arc
        track.strokeWidth = ringW
        canvas.drawArc(rect, 135f, 270f, false, track)
        if (frac > 0.001f) {
            prog.strokeWidth = ringW
            glow.strokeWidth = ringW * 1.5f
            canvas.drawArc(rect, 135f, 270f * frac, false, glow)
            canvas.drawArc(rect, 135f, 270f * frac, false, prog)
        }

        // Ticks and numbers
        val perMajor = if (majorStep >= 20f) 4 else 5
        val minorStep = majorStep / perMajor
        val outer = r - ringW - 4f * d
        labelPaint.textSize = r * 0.075f
        var i = 0
        while (true) {
            val v = i * minorStep
            if (v > maxScale + 0.01f) break
            val a = angleFor(v)
            val isMajor = i % perMajor == 0
            val len = if (isMajor) r * 0.075f else r * 0.04f
            val x1 = cx + cos(a).toFloat() * outer
            val y1 = cy + sin(a).toFloat() * outer
            val x2 = cx + cos(a).toFloat() * (outer - len)
            val y2 = cy + sin(a).toFloat() * (outer - len)
            canvas.drawLine(x1, y1, x2, y2, if (isMajor) majorTick else minorTick)
            if (isMajor) {
                val lr = outer - len - r * 0.07f
                canvas.centerText(
                    v.roundToInt().toString(),
                    cx + cos(a).toFloat() * lr,
                    cy + sin(a).toFloat() * lr,
                    labelPaint
                )
            }
            i++
        }

        // Max-speed marker (white dot) and limit marker (red dot) on the ring
        if (recordedMax > 0.5f) {
            val a = angleFor(recordedMax)
            dot.color = Color.WHITE
            canvas.drawCircle(
                cx + cos(a).toFloat() * arcR, cy + sin(a).toFloat() * arcR, ringW * 0.32f, dot
            )
        }
        if (limit > 0f && limit <= maxScale) {
            val a = angleFor(limit)
            dot.color = Color.parseColor("#FF1744")
            canvas.drawCircle(
                cx + cos(a).toFloat() * arcR, cy + sin(a).toFloat() * arcR, ringW * 0.42f, dot
            )
        }

        // Needle
        val angleDeg = 135f + 270f * frac
        canvas.save()
        canvas.rotate(angleDeg, cx, cy)
        needlePath.reset()
        needlePath.moveTo(cx + r * 0.80f, cy)
        needlePath.lineTo(cx, cy - 5f * d)
        needlePath.lineTo(cx - r * 0.13f, cy)
        needlePath.lineTo(cx, cy + 5f * d)
        needlePath.close()
        canvas.drawPath(needlePath, needle)
        canvas.restore()

        // Hub
        canvas.drawCircle(cx, cy, r * 0.075f, hub)
        hubRing.color = accent
        canvas.drawCircle(cx, cy, r * 0.075f, hubRing)

        // Caption, digital speed, unit
        captionPaint.textSize = r * 0.07f
        canvas.centerText(caption, cx, cy - r * 0.30f, captionPaint)
        speedPaint.textSize = r * 0.34f
        canvas.centerText(shown.roundToInt().toString(), cx, cy + r * 0.45f, speedPaint)
        unitPaint.textSize = r * 0.10f
        canvas.centerText(unitLabel, cx, cy + r * 0.68f, unitPaint)

        // Over-limit pulsing red ring
        if (limit > 0f && shown > limit) {
            val pulse = (0.5 + 0.5 * sin(System.currentTimeMillis() / 110.0)).toFloat()
            warn.alpha = (80 + 175 * pulse).toInt()
            canvas.drawCircle(cx, cy, r + 4f * d, warn)
            postInvalidateOnAnimation()
        }
    }
}
