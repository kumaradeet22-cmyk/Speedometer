package com.maxspeedo.app

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import kotlin.math.PI
import kotlin.math.roundToInt
import kotlin.math.sin

/**
 * MaxSpeedo - GPS speedometer for bicycle / motorcycle / car.
 * Features: animated gauge, 3 vehicle modes, km/h-mph-knots, trip distance / max / avg / moving time,
 * altitude + compass heading, GPS quality, speed-limit alert (red pulse + beep + vibration),
 * HUD mirror mode, demo mode, landscape layout, keep-screen-on, trip saved between launches.
 */
class MainActivity : Activity(), LocationListener {

    private val vehicleNames = arrayOf("BICYCLE", "MOTORCYCLE", "CAR")
    private val vehicleIcons = arrayOf("🚲", "🏍", "🚗")
    private val accents = intArrayOf(
        Color.parseColor("#00E676"), Color.parseColor("#FF9100"), Color.parseColor("#00B0FF")
    )
    private val unitNames = arrayOf("km/h", "mph", "knots")
    private val distNames = arrayOf("km", "mi", "nmi")
    private val speedFactor = doubleArrayOf(3.6, 2.236936, 1.943844)       // m/s -> unit
    private val distFactor = doubleArrayOf(0.001, 0.000621371, 0.000539957) // m -> unit
    private val scaleMax = arrayOf(
        floatArrayOf(60f, 40f, 30f),
        floatArrayOf(240f, 160f, 120f),
        floatArrayOf(320f, 200f, 180f)
    )
    private val scaleStep = arrayOf(
        floatArrayOf(10f, 5f, 5f),
        floatArrayOf(20f, 20f, 20f),
        floatArrayOf(40f, 20f, 20f)
    )
    private val compass = arrayOf("N", "NE", "E", "SE", "S", "SW", "W", "NW")

    private lateinit var prefs: SharedPreferences
    private lateinit var root: LinearLayout
    private lateinit var gauge: SpeedometerView
    private lateinit var scroll: ScrollView
    private lateinit var gpsText: TextView
    private lateinit var vehicleBtn: Button
    private lateinit var unitBtn: Button
    private lateinit var limitBtn: Button
    private lateinit var hudBtn: Button
    private lateinit var demoBtn: Button
    private val stat = HashMap<String, TextView>()

    private var vehicle = 1
    private var unit = 0
    private var limitMs = 0f
    private var hud = false
    private var demo = false

    private var distM = 0.0
    private var maxMs = 0f
    private var movingMs = 0L
    private var lastLoc: Location? = null
    private var lastFixAt = 0L
    private var wasOver = false
    private var demoT = 0.0
    private var tone: ToneGenerator? = null

    private val ui = Handler(Looper.getMainLooper())

    private val demoTick = object : Runnable {
        override fun run() {
            if (!demo) return
            demoT += 0.03
            val frac = sin(demoT - PI / 2) * 0.5 + 0.5
            val unitSpeed = frac * scaleMax[vehicle][unit] * 0.95
            applySpeed((unitSpeed / speedFactor[unit]).toFloat(), false, 250L)
            ui.postDelayed(this, 120L)
        }
    }

    private val watchdog = object : Runnable {
        override fun run() {
            if (!demo && lastFixAt != 0L &&
                SystemClock.elapsedRealtime() - lastFixAt > 3000L && gauge.shown > 0.5f
            ) {
                applySpeed(0f, false)
            }
            ui.postDelayed(this, 1000L)
        }
    }

    // ---------------------------------------------------------------- lifecycle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("maxspeedo", Context.MODE_PRIVATE)
        loadPrefs()
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.statusBarColor = Color.parseColor("#0B0F14")
        window.navigationBarColor = Color.parseColor("#0B0F14")
        buildUi()
        refreshAll()
        gauge.post { gauge.startupSweep() }
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION),
                1
            )
        }
    }

    override fun onResume() {
        super.onResume()
        lastLoc = null
        startLocation()
        ui.postDelayed(watchdog, 1000L)
        if (demo) ui.post(demoTick)
    }

    override fun onPause() {
        super.onPause()
        try {
            (getSystemService(Context.LOCATION_SERVICE) as LocationManager).removeUpdates(this)
        } catch (e: SecurityException) {
        }
        ui.removeCallbacks(watchdog)
        ui.removeCallbacks(demoTick)
        savePrefs()
    }

    override fun onDestroy() {
        super.onDestroy()
        tone?.release()
        tone = null
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        applyOrientation(newConfig.orientation)
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        startLocation()
    }

    // ---------------------------------------------------------------- UI

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun buildUi() {
        root = LinearLayout(this).apply { setBackgroundColor(Color.parseColor("#0B0F14")) }
        gauge = SpeedometerView(this)
        gauge.setOnClickListener { if (hud) toggleHud() }
        scroll = ScrollView(this)

        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(2), dp(12), dp(12))
        }
        gpsText = TextView(this).apply {
            textSize = 13f
            setTextColor(Color.parseColor("#8FA1B3"))
            gravity = Gravity.CENTER
            setPadding(0, dp(2), 0, dp(8))
        }
        panel.addView(gpsText)
        panel.addView(statRow("DISTANCE" to "dist", "MAX" to "max", "AVG" to "avg"))
        panel.addView(statRow("MOVING" to "time", "ALTITUDE" to "alt", "HEADING" to "hdg"))

        vehicleBtn = btn("") { vehicle = (vehicle + 1) % 3; refreshAll() }
        unitBtn = btn("") { unit = (unit + 1) % 3; refreshAll() }
        limitBtn = btn("") { cycleLimit() }
        hudBtn = btn("") { toggleHud() }
        demoBtn = btn("") { toggleDemo() }
        val resetBtn = btn("↻  Reset trip") { resetTrip() }

        panel.addView(btnRow(vehicleBtn, unitBtn))
        panel.addView(btnRow(limitBtn, hudBtn))
        panel.addView(btnRow(demoBtn, resetBtn))

        scroll.addView(panel)
        root.addView(gauge)
        root.addView(scroll)
        setContentView(root)
        applyOrientation(resources.configuration.orientation)
    }

    private fun applyOrientation(orientation: Int) {
        if (orientation == Configuration.ORIENTATION_LANDSCAPE) {
            root.orientation = LinearLayout.HORIZONTAL
            gauge.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1.1f)
            scroll.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 0.9f)
        } else {
            root.orientation = LinearLayout.VERTICAL
            gauge.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
            scroll.layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }
    }

    private fun statRow(vararg items: Pair<String, String>): LinearLayout {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(6), 0, dp(6))
        }
        for ((label, key) in items) {
            val block = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            }
            block.addView(TextView(this).apply {
                text = label
                textSize = 10f
                setTextColor(Color.parseColor("#5C6B7A"))
                gravity = Gravity.CENTER
            })
            val value = TextView(this).apply {
                text = "--"
                textSize = 18f
                setTextColor(Color.WHITE)
                gravity = Gravity.CENTER
                typeface = android.graphics.Typeface.DEFAULT_BOLD
            }
            stat[key] = value
            block.addView(value)
            row.addView(block)
        }
        return row
    }

    private fun btn(label: String, onClick: () -> Unit): Button = Button(this).apply {
        text = label
        setTextColor(Color.WHITE)
        textSize = 13f
        isAllCaps = false
        background = GradientDrawable().apply {
            cornerRadius = dp(14).toFloat()
            setColor(Color.parseColor("#17212B"))
            setStroke(dp(1), Color.parseColor("#2C3B4A"))
        }
        setOnClickListener { onClick() }
        layoutParams = LinearLayout.LayoutParams(0, dp(48), 1f).apply {
            setMargins(dp(4), dp(4), dp(4), dp(4))
        }
    }

    private fun btnRow(a: Button, b: Button): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        addView(a)
        addView(b)
    }

    // ---------------------------------------------------------------- state changes

    private fun refreshAll() {
        gauge.maxScale = scaleMax[vehicle][unit]
        gauge.majorStep = scaleStep[vehicle][unit]
        gauge.unitLabel = unitNames[unit]
        gauge.caption = vehicleNames[vehicle]
        gauge.accent = accents[vehicle]
        gauge.limit = (limitMs * speedFactor[unit]).toFloat()
        gauge.recordedMax = (maxMs * speedFactor[unit]).toFloat()
        vehicleBtn.text = vehicleIcons[vehicle] + "  " + vehicleNames[vehicle]
        unitBtn.text = "⇅  " + unitNames[unit]
        limitBtn.text = if (limitMs <= 0f) "⚠  Limit: OFF"
        else "⚠  Limit: ${(limitMs * speedFactor[unit]).roundToInt()} ${unitNames[unit]}"
        hudBtn.text = if (hud) "▣  HUD: ON" else "▢  HUD: OFF"
        demoBtn.text = if (demo) "■  Stop demo" else "▶  Demo"
        gauge.scaleX = if (hud) -1f else 1f
        scroll.visibility = if (hud) View.GONE else View.VISIBLE
        savePrefs()
        updateStats()
    }

    private fun cycleLimit() {
        val sf = speedFactor[unit]
        val step = if (vehicle == 0) 5 else 10
        val current = (limitMs * sf).roundToInt()
        val next = if (limitMs <= 0f) step else current + step
        limitMs = if (next > scaleMax[vehicle][unit] * 0.95f) 0f else (next / sf).toFloat()
        wasOver = false
        refreshAll()
    }

    private fun toggleHud() {
        hud = !hud
        if (hud) Toast.makeText(this, "Tap the gauge to exit HUD", Toast.LENGTH_SHORT).show()
        refreshAll()
    }

    private fun toggleDemo() {
        demo = !demo
        if (demo) {
            demoT = 0.0
            ui.post(demoTick)
        } else {
            ui.removeCallbacks(demoTick)
            applySpeed(0f, false)
        }
        refreshAll()
    }

    private fun resetTrip() {
        distM = 0.0
        maxMs = 0f
        movingMs = 0L
        lastLoc = null
        gauge.recordedMax = 0f
        updateStats()
        Toast.makeText(this, "Trip reset", Toast.LENGTH_SHORT).show()
    }

    private fun applySpeed(v: Float, record: Boolean = true, animMs: Long = 400L) {
        gauge.setSpeed((v * speedFactor[unit]).toFloat(), animMs)
        if (record && v > maxMs) {
            maxMs = v
            gauge.recordedMax = (maxMs * speedFactor[unit]).toFloat()
        }
        val over = limitMs > 0f && v > limitMs
        if (over && !wasOver) alert()
        wasOver = over
        updateStats()
    }

    private fun alert() {
        try {
            val vib = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            if (Build.VERSION.SDK_INT >= 26) {
                vib.vibrate(VibrationEffect.createOneShot(350L, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                vib.vibrate(350L)
            }
        } catch (e: Exception) {
        }
        try {
            if (tone == null) tone = ToneGenerator(AudioManager.STREAM_ALARM, 80)
            tone?.startTone(ToneGenerator.TONE_PROP_BEEP, 300)
        } catch (e: Exception) {
        }
    }

    private fun updateStats() {
        val sf = speedFactor[unit]
        stat["dist"]?.text = String.format("%.2f %s", distM * distFactor[unit], distNames[unit])
        stat["max"]?.text = String.format("%.0f %s", maxMs * sf, unitNames[unit])
        val avgMs = if (movingMs > 0L) distM / (movingMs / 1000.0) else 0.0
        stat["avg"]?.text = String.format("%.1f %s", avgMs * sf, unitNames[unit])
        val s = movingMs / 1000
        stat["time"]?.text = String.format("%d:%02d:%02d", s / 3600, (s % 3600) / 60, s % 60)
        val loc = lastLoc
        stat["alt"]?.text = if (loc != null && loc.hasAltitude()) {
            if (unit == 1) String.format("%.0f ft", loc.altitude * 3.28084)
            else String.format("%.0f m", loc.altitude)
        } else "--"
        stat["hdg"]?.text = if (loc != null && loc.hasBearing() && gauge.shown > 1f) {
            val idx = (((loc.bearing + 22.5f) / 45f).toInt()) % 8
            "${compass[idx]} ${loc.bearing.roundToInt()}°"
        } else "--"
    }

    // ---------------------------------------------------------------- location

    private fun startLocation() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            gpsText.text = "GPS ○  location permission needed"
            return
        }
        val lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        try {
            gpsText.text = if (lm.isProviderEnabled(LocationManager.GPS_PROVIDER))
                "GPS ◌  searching for satellites…"
            else "GPS ○  turn on Location in phone settings"
            lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 500L, 0f, this)
        } catch (e: SecurityException) {
            gpsText.text = "GPS ○  location permission needed"
        } catch (e: IllegalArgumentException) {
            gpsText.text = "GPS ○  not available on this device"
        }
    }

    override fun onLocationChanged(location: Location) {
        if (demo) return
        lastFixAt = SystemClock.elapsedRealtime()
        val acc = if (location.hasAccuracy()) location.accuracy else 99f
        val (quality, color) = when {
            acc <= 10f -> "EXCELLENT" to "#00E676"
            acc <= 25f -> "GOOD" to "#FFEA00"
            else -> "WEAK" to "#FF5252"
        }
        gpsText.text = "GPS ●  $quality  ±${acc.roundToInt()} m"
        gpsText.setTextColor(Color.parseColor(color))

        var v = if (location.hasSpeed()) location.speed else 0f
        if (v < 0.5f) v = 0f // ignore GPS drift while standing still

        val prev = lastLoc
        if (prev != null && v > 0f && acc < 30f) {
            val dtMs = (location.elapsedRealtimeNanos - prev.elapsedRealtimeNanos) / 1_000_000L
            if (dtMs in 1L..10_000L) {
                movingMs += dtMs
                distM += prev.distanceTo(location).toDouble()
            }
        }
        lastLoc = location
        applySpeed(v)
    }

    @Deprecated("Required for pre-Q devices")
    override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {
    }

    override fun onProviderEnabled(provider: String) {
        startLocation()
    }

    override fun onProviderDisabled(provider: String) {
        gpsText.text = "GPS ○  turn on Location in phone settings"
        gpsText.setTextColor(Color.parseColor("#FF5252"))
    }

    // ---------------------------------------------------------------- persistence

    private fun loadPrefs() {
        vehicle = prefs.getInt("vehicle", 1)
        unit = prefs.getInt("unit", 0)
        limitMs = prefs.getFloat("limitMs", 0f)
        hud = false
        distM = prefs.getFloat("distM", 0f).toDouble()
        maxMs = prefs.getFloat("maxMs", 0f)
        movingMs = prefs.getLong("movingMs", 0L)
    }

    private fun savePrefs() {
        prefs.edit()
            .putInt("vehicle", vehicle)
            .putInt("unit", unit)
            .putFloat("limitMs", limitMs)
            .putFloat("distM", distM.toFloat())
            .putFloat("maxMs", maxMs)
            .putLong("movingMs", movingMs)
            .apply()
    }
}
